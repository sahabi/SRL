from pybrain.rl.environments.twoplayergames.capturegame import CaptureGame
from pybrain.rl.environments.twoplayergames.gomoku import GomokuGame
from pybrain.rl.environments.twoplayergames.tasks.__init__ import *