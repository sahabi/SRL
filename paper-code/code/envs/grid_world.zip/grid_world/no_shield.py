class Shield:
  def tick(self, inputs):    
    return [ inputs[-3], inputs[-2], inputs[-1], 0]
